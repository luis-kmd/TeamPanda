document.addEventListener('DOMContentLoaded', function() {
    // Elementos do DOM
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.querySelector('.main-content');
    const toggleMenu = document.getElementById('toggle-menu');
    const menuItems = document.querySelectorAll('.menu-item');
    const contentSections = document.querySelectorAll('.content-section');
    
    // Atualizar hora e temperatura
    updateTime();
    getWeather();
    
    // Atualizar hora a cada minuto
    setInterval(updateTime, 60000);
    
    // Toggle do menu lateral
    toggleMenu.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        sidebar.classList.toggle('expanded');
        mainContent.classList.toggle('expanded');
    });
    
    // Navegação entre seções
    menuItems.forEach(item => {
        item.addEventListener('click', function() {
            // Atualizar item ativo no menu
            menuItems.forEach(i => i.classList.remove('active'));
            this.classList.add('active');
            
            // Mostrar seção correspondente
            const contentId = this.getAttribute('data-content') + '-content';
            contentSections.forEach(section => {
                section.classList.remove('active');
                if (section.id === contentId) {
                    section.classList.add('active');
                }
            });
            
            // Em dispositivos móveis, fechar o menu após a seleção
            if (window.innerWidth <= 768) {
                sidebar.classList.add('collapsed');
                sidebar.classList.remove('expanded');
                mainContent.classList.add('expanded');
            }
        });
    });
    
    // Responsividade para dispositivos móveis
    window.addEventListener('resize', function() {
        if (window.innerWidth <= 768) {
            sidebar.classList.add('collapsed');
            sidebar.classList.remove('expanded');
            mainContent.classList.add('expanded');
        } else {
            sidebar.classList.remove('collapsed');
            sidebar.classList.remove('expanded');
            mainContent.classList.remove('expanded');
        }
    });
    
    // Inicializar em modo móvel se necessário
    if (window.innerWidth <= 768) {
        sidebar.classList.add('collapsed');
        mainContent.classList.add('expanded');
    }
    
    // Função para atualizar a hora
    function updateTime() {
        const now = new Date();
        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        document.getElementById('current-time').textContent = `${hours}:${minutes}`;
    }
    
    // Função para obter a temperatura (simulada)
    function getWeather() {
        // Em uma aplicação real, você usaria uma API de clima
        // Aqui estamos apenas simulando
        const temperatures = [22, 23, 24, 25, 26, 27, 28];
        const randomTemp = temperatures[Math.floor(Math.random() * temperatures.length)];
        document.getElementById('temperature').textContent = `${randomTemp}°C`;
    }
    
    // Adicionar funcionalidade aos botões (simulado)
    const editButtons = document.querySelectorAll('.edit-btn, .edit-plan, .edit-payment');
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            alert('Função de edição será implementada aqui.');
        });
    });
    
    const viewButtons = document.querySelectorAll('.view-students, .action-btn.view');
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            alert('Visualização de detalhes será implementada aqui.');
        });
    });
    
    const addButtons = document.querySelectorAll('.add-btn, .add-payment-btn, .add-plan');
    addButtons.forEach(button => {
        button.addEventListener('click', function() {
            alert('Formulário de adição será implementado aqui.');
        });
    });
    
    // Adicionar funcionalidade aos botões de relatórios
    const generateReportBtn = document.querySelector('.generate-report-btn');
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', function() {
            alert('Gerando relatório... Esta funcionalidade será implementada em breve.');
        });
    }
    
    const viewReportBtns = document.querySelectorAll('.view-report');
    viewReportBtns.forEach(button => {
        button.addEventListener('click', function() {
            alert('Visualizando relatório... Esta funcionalidade será implementada em breve.');
        });
    });
    
    const downloadReportBtns = document.querySelectorAll('.download-report');
    downloadReportBtns.forEach(button => {
        button.addEventListener('click', function() {
            alert('Baixando relatório... Esta funcionalidade será implementada em breve.');
        });
    });
    
    const newReportCard = document.querySelector('.report-card.new-report');
    if (newReportCard) {
        newReportCard.addEventListener('click', function() {
            alert('Criando novo relatório personalizado... Esta funcionalidade será implementada em breve.');
        });
    }
});